
export const customerBookingEmail = (booking: any) => {
  return `
<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Booking Notification</title>
</head>

<body style="
margin:0;
padding:0;
background:#f4f4f4;
font-family:Arial,Helvetica,sans-serif;
">

<div style="
padding:20px;
background:#f4f4f4;
">

<div style="
width:100%;
max-width:800px;
margin:auto;
background:#ffffff;
border-radius:10px;
overflow:hidden;
box-shadow:0 2px 12px rgba(0,0,0,0.08);
">

<!-- HEADER -->

<div style="
background:#5a0f2e;
padding:25px;
text-align:center;
">

<img
src="https://locationshub.in/images/loaction-hub-logo-final.svg"
alt="Locations Hub"
style="height:60px;max-width:220px;"
/>

</div>

<!-- TITLE -->

<div style="
padding:40px 30px;
text-align:center;
">





</div>

<hr style="
border:none;
border-top:1px solid #ececec;
margin:0;
">

<!-- BOOKING DETAILS -->

<div style="
padding:30px;
">

<h2 style="
text-align:center;
font-size:28px;
color:#222;
margin:0 0 25px 0;
">

<span style="
background:#f3d67b;
padding:4px 10px;
border-radius:4px;
">
Booking
</span>

Details

</h2>

<table
style="
width:100%;
border-collapse:collapse;
table-layout:fixed;
">

<tr>
<td style="padding:16px;border-bottom:1px solid #eee;color:#555;">
Booking ID
</td>

<td style="
padding:16px;
border-bottom:1px solid #eee;
text-align:right;
font-weight:600;
color:#222;
">
${booking.bookingId}
</td>
</tr>

<tr>
<td style="padding:16px;border-bottom:1px solid #eee;color:#555;">
Name
</td>

<td style="
padding:16px;
border-bottom:1px solid #eee;
text-align:right;
font-weight:600;
">
${booking.name}
</td>
</tr>

<tr>
<td style="padding:16px;border-bottom:1px solid #eee;color:#555;">
Booking Date
</td>

<td style="
padding:16px;
border-bottom:1px solid #eee;
text-align:right;
font-weight:600;
">
${new Date(booking.date).toLocaleDateString("en-GB").replace(/\//g, "-")}
</td>
</tr>

<tr>
<td style="padding:16px;border-bottom:1px solid #eee;color:#555;">
Package
</td>

<td style="
padding:16px;
border-bottom:1px solid #eee;
text-align:right;
font-weight:600;
">
${booking.package}
</td>
</tr>

<tr>
<td style="padding:16px;border-bottom:1px solid #eee;color:#555;">
Timings
</td>

<td style="
padding:16px;
border-bottom:1px solid #eee;
text-align:right;
font-weight:600;
">
${booking.slots}
</td>
</tr>

<tr>
<td style="padding:16px;border-bottom:1px solid #eee;color:#555;">
Package Cost
</td>

<td style="
padding:16px;
border-bottom:1px solid #eee;
text-align:right;
font-weight:600;
">
₹${booking.packageCost}
</td>
</tr>

<tr>
<td style="padding:16px;border-bottom:1px solid #eee;color:#555;">
Booking Cost
</td>

<td style="
padding:16px;
border-bottom:1px solid #eee;
text-align:right;
font-weight:600;
">
₹${booking.bookingCost}
</td>
</tr>

<tr>
<td style="padding:16px;border-bottom:1px solid #eee;color:#555;">
GST on Booking Cost (18%)
</td>

<td style="
padding:16px;
border-bottom:1px solid #eee;
text-align:right;
font-weight:600;
">
₹${booking.gstAmount}
</td>
</tr>

<tr>
<td style="padding:16px;border-bottom:1px solid #eee;color:#555;">
Total Paid
</td>

<td style="
padding:16px;
border-bottom:1px solid #eee;
text-align:right;
font-weight:700;
color:#0b7a24;
">
₹${booking.totalPaid}
</td>
</tr>

<tr>
<td style="padding:16px;border-bottom:1px solid #eee;color:#555;">
Balance Due
</td>

<td style="
padding:16px;
border-bottom:1px solid #eee;
text-align:right;
font-weight:700;
color:#c0392b;
">
₹${booking.due}
</td>
</tr>

<tr>
<td style="padding:16px;border-bottom:1px solid #eee;color:#555;">
Payment Method
</td>

<td style="
padding:16px;
border-bottom:1px solid #eee;
text-align:right;
font-weight:600;
">
${booking.paymentMethod}
</td>
</tr>

</table>
</div>

<!-- NOTES -->

<div style="
padding:30px;
color:#555;
">

<h3 style="
margin-top:0;
font-size:24px;
color:#222;
">
Please Note
</h3>

<ol style="
padding-left:25px;
line-height:2;
font-size:15px;
">

<li>Timings cannot be shifted.</li>

<li>Please reach 20 mins prior for payment and booking formalities.</li>

<li>Dues + Deposit (Refundable) to be paid before the shoot.</li>

<li>Please carry your ID Proof.</li>

<li>Outside Food and Beverages are not allowed.</li>

<li>All Sets & Props are on sharing basis. Cooperative behavior is expected.</li>

<li>
Download Google Location Offline before starting.
<br>
<a href="https://maps.app.goo.gl/6pPZoJ6wMU8tsGET6">
Open Map
</a>
</li>

<li>
Locations Hub Manager
<br>
Prashant: +91 8169232114
</li>

</ol>

</div>

<hr style="
border:none;
border-top:1px solid #ececec;
margin:0;
">

<!-- BILLING -->

<div style="
padding:40px 30px;
background:#fafafa;
text-align:center;
">

<h2 style="
margin-top:0;
color:#222;
">
Billing Address
</h2>

<p style="
line-height:1.8;
color:#555;
margin:0;
">

${booking.name}<br>

${booking.address}<br>

${booking.city} ${booking.postcode}<br>

${booking.state}

<br><br>

<a href="tel:${booking.phone}">
${booking.phone}
</a>

<br><br>

<a href="mailto:${booking.email}">
${booking.email}
</a>

</p>

</div>

<!-- FOOTER -->

<div style="
text-align:center;
padding:25px;
background:#fafafa;
color:#999;
font-size:13px;
">

Copyright © ${new Date().getFullYear()}
Locations Hub.
All Rights Reserved.

</div>

</div>

</div>

</body>
</html>
`;
};